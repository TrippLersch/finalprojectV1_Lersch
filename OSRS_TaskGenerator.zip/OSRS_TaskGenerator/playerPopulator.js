var mysql = require('mysql');
const { faker } = require('@faker-js/faker');

var con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    database: 'task_generator'
});


// fill out x number of player data
let x = 5;
for (let i = 0; i < x; i++) {
    const skills = ["attack_lvl", "hitpoints_lvl", "mining_lvl", "strength_lvl", "agility_lvl", "smithing_lvl", "defence_lvl", "herblore_lvl", "fishing_lvl", "range_lvl", "theiving_lvl", "cooking_lvl", "prayer_lvl", "crafting_lvl", "firemaking_lvl", "magic_lvl", "fletching_lvl", "woodcutting_lvl", "runecrafting_lvl", "slayer_lvl", "farming_lvl", "construction_lvl", "hunter_lvl"];
    var randomName = faker.person.fullName();
    var q = "insert into players (player_name, attack_lvl, hitpoints_lvl, mining_lvl, strength_lvl, agility_lvl, smithing_lvl, defence_lvl, herblore_lvl, fishing_lvl, range_lvl, theiving_lvl, cooking_lvl, prayer_lvl, crafting_lvl, firemaking_lvl, magic_lvl, fletching_lvl, woodcutting_lvl, runecrafting_lvl, slayer_lvl, farming_lvl, construction_lvl, hunter_lvl, total_lvl) values ('" + randomName +"'";
    let levelCount = 0;
    for (const skill of skills) {
        let newSkillLevel = Math.floor((Math.random() * 99) + 1);
        skillQuery = ", " + newSkillLevel;
        q += skillQuery;
        levelCount += newSkillLevel;
    }

    q += ", " + levelCount + ");";
    console.log(q);

    con.query(q, function(err, results, fields) {
        if(err) throw err;
        console.log("Data Insert Succesful");
    });
}


con.end();



