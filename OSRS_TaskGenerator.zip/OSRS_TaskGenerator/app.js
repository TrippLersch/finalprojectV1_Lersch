var express = require('express');
var app = express();
const morgan = require("morgan");

// connect to database
var mysql = require('mysql');

var con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    database: 'task_generator'
});

app.use(express.static("public")); //middleware function
app.use(morgan('dev')); // logs HTTP resuests in the console

app.listen(8080, function () {
    console.log('App listening on port 8080!');
});

