var mysql = require('mysql');
const { faker } = require('@faker-js/faker');

var con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    database: 'task_generator'
});

// for now generate 5 of each for proof of concept
// insert easy tasks
easy_Task_queries = [
    "insert into tasks (task_name, tier) values ('Complete 5 easy clues', 'easy')",
    "insert into tasks (task_name, tier, fishing_req) values ('Play one game of Temperos', 'easy', 35)",
    "insert into tasks (task_name, tier, fishing_req, cooking_req) values ('Fish and Cook a Tuna', 'easy', 35, 30)"
]

for (const task in easy_Task_queries){
    q = task;
    con.query(q, function(err, results, fields) {
        if(err) throw err;
        console.log("Easy Tasks Inserted");
    });
}

// insert medium tasks
medium_Task_queries = [
    "insert into tasks (task_name, tier, prayer_req) values ('Kill Scurrius', 'medium', 43)",
    "insert into tasks (task_name, tier) values ('Complete 3 combat achievements', 'medium')",
    "insert into tasks (task_name, tier) values ('Get combat level 60', 'medium')"
]

for (const task in medium_Task_queries){
    q = task;
    con.query(q, function(err, results, fields) {
        if(err) throw err;
        console.log("Easy Tasks Inserted");
    });
}

// insert hard tasks
hard_Task_queries = [
    "insert into tasks (task_name, tier) values ('Kill Sarachnis', 'hard')",
    "insert into tasks (task_name, tier) values ('Get combat level 100', 'hard')",
    "insert into tasks (task_name, tier) values ('get prayer level 70', 'hard')"
]

for (const task in hard_Task_queries){
    q = task;
    con.query(q, function(err, results, fields) {
        if(err) throw err;
        console.log("Easy Tasks Inserted");
    });
}

// insert elite tasks
elite_Task_queries = [
    "insert into tasks (task_name, tier, cooking_lvl) values ('Cook a shark', 'elite', 80)",
    "insert into tasks (task_name, tier) values ('Complete an elite clue', 'elite')",
    "insert into tasks (task_name, tier, slayer_lvl) values ('Kill Grotesque Guardians', 'elite', 83)"
]

for (const task in elite_Task_queries){
    q = task;
    con.query(q, function(err, results, fields) {
        if(err) throw err;
        console.log("Easy Tasks Inserted");
    });
}



con.end()