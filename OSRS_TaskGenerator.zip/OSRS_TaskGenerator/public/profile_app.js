// update stats
searchPlayer.addEventListener('click', function(){
    // adds username
    username = document.getElementById("username").value;
    document.getElementById("tableUsername").innerHTML = "Username: " + username;

    q = "select * from players where player_name = " + document.getElementById("username").value;
    var skills = con.query(q, function(err, results, fields) {
        if(err) throw err;
        console.log("Data Insert Succesful");
    });
    
    console.log(skills);

    /* for (const skill of skills) {
        // update skill levels for user
        document.getElementById(skill).innerHTML = skill + ": " + newSkillLevel + "/99";
    };
    */ 
    // update total level
    document.getElementById("totalLevel").innerHTML = "Total Level: " + totalLevel;
})