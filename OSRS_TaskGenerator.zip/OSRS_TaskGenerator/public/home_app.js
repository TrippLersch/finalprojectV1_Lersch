// set of various tasks until database implementation
easyTasks = [""];
mediumTasks = [""];
hardTasks = [""];
eliteTasks = [""];


generateTask.addEventListener('click', function(){
    alert('hello world')
});

